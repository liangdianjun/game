package com.fivechess;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.util.Date;
import java.util.Random;
import javax.swing.*;

public class Register extends JFrame{

	/*
	 * 用户注册
	 */
	final JLabel welcomeRegisterLabel = new JLabel("欢迎注册开心五子棋！");
	final JLabel userLabel = new JLabel("用户名：");
	final JTextField userjt = new JTextField(14);
	final JLabel passwordLabel = new JLabel("密码：");
	final JPasswordField passwordjp = new JPasswordField(14);
	final JLabel confirmPasswordLabel = new JLabel("确认密码：");
	final JPasswordField confirmPasswordjp = new JPasswordField(14);
	final JLabel yanzhengmajl = new JLabel("验证码：");
	final JTextField yanzhengmajt = new JTextField("请输入验证码", 7);
	final JLabel yanzhengmaUpdate = new JLabel("看不清？换一张");
	final JButton register = new JButton("               注  册               ");
	final JLabel back = new JLabel("返回");
	final JLabel tipUserAlreadyRegistered = new JLabel("该账号已经注册！");
	final JLabel tipUserNameEmpty = new JLabel("用户名为空！");
	final JLabel tipUserNameLessThan5Char = new JLabel("账号少于5个字符！");
	final JLabel tipPasswordEmpty = new JLabel("密码不能为空!");
	final JLabel tipPasswordLessThan6Char = new JLabel("密码少于6个字符！");
	final JLabel tipPasswordInconfirmity = new JLabel("两次密码不一致!");
	final JLabel tipConfirmPasswordqualified = new JLabel("重复密码正确！");
	final JLabel tipyanzhengmaerror = new JLabel("验证码输入不正确!");
	final DrawYZM drawyzm = new DrawYZM();
	final Random r = new Random();
	static String userName = new String();
	static String password = new String();
	final FileOperation read = new FileOperation();
	String repeatPassword = new String();
	String yanzhengma = new String();
	String yzm = new String();
	int flagUserName = 0;
	int flagPassword = 0;
	int flagConfirmedPassword = 0;
	int flagyanzhengma = 0;
	char[] YZM = new char[62];{
		for(int i = 0; i < 26; i++) {
			YZM[i] = (char) ('A' + i);
		}
		for(int i = 26; i< 52; i++) {
			YZM[i] = (char) ('a' + i - 26);
		}
		for(char i = 52; i < 62; i++) {
			YZM[i] = (char) (i - 4);
		}
	}
	SpringLayout springLayout = new SpringLayout();//使用弹簧布局管理器
	
	public Register() {
		Container c = getContentPane();//创建容器
		setVisible(true);
		c.setBackground(new Color(255, 218, 185));
		setBounds(200, 200, 500, 500);
		setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
		c.setLayout(springLayout);
		setTitle("用户注册");
		c.add(drawyzm);
		
		welcomeRegisterLabel.setFont(new Font("微软雅黑", 1, 36));//设置样式
		welcomeRegisterLabel.setForeground(Color.pink);
		userLabel.setFont(new Font("微软雅黑", 1, 18));
		userjt.setFont(new Font("微软雅黑", 0, 17));
		passwordLabel.setFont(new Font("微软雅黑", 1, 18));
		passwordjp.setFont(new Font("微软雅黑", 0, 17));
		confirmPasswordLabel.setFont(new Font("微软雅黑", 1, 18));
		confirmPasswordjp.setFont(new Font("微软雅黑", 0, 17));
		register.setFont(new Font("微软雅黑", 1, 18));
		back.setFont(new Font("微软雅黑", 0, 13));
		back.setForeground(Color.gray);
		register.setForeground(Color.gray);
		yanzhengmajt.setFont(new Font("微软雅黑", 0, 17));
		yanzhengmajl.setFont(new Font("微软雅黑", 1, 18));
		yanzhengmaUpdate.setFont(new Font("微软雅黑", 0, 13));
		Font tipFont = new Font("微软雅黑", 0, 13);//设置提示字体显示样式
		tipUserAlreadyRegistered.setFont(tipFont);
		tipUserAlreadyRegistered.setForeground(Color.red);
		tipUserAlreadyRegistered.setVisible(false);
		tipUserNameEmpty.setFont(tipFont);
		tipUserNameEmpty.setForeground(Color.red);
		tipUserNameEmpty.setVisible(false);
		tipUserNameLessThan5Char.setFont(tipFont);
		tipUserNameLessThan5Char.setForeground(Color.red);
		tipUserNameLessThan5Char.setVisible(false);
		tipPasswordEmpty.setFont(tipFont);
		tipPasswordEmpty.setForeground(Color.red);
		tipPasswordEmpty.setVisible(false);
		tipPasswordLessThan6Char.setFont(tipFont);
		tipPasswordLessThan6Char.setForeground(Color.red);
		tipPasswordLessThan6Char.setVisible(false);
		tipPasswordInconfirmity.setFont(tipFont);
		tipPasswordInconfirmity.setForeground(Color.red);
		tipPasswordInconfirmity.setVisible(false);
		tipConfirmPasswordqualified.setFont(tipFont);
		tipConfirmPasswordqualified.setForeground(new Color(50, 205, 50));
		tipConfirmPasswordqualified.setVisible(false);
		tipyanzhengmaerror.setFont(tipFont);
		tipyanzhengmaerror.setForeground(Color.red);
		tipyanzhengmaerror.setVisible(false);
	
		c.add(welcomeRegisterLabel);//标签设置
		springLayout.putConstraint(springLayout.NORTH, welcomeRegisterLabel, 50, springLayout.NORTH, c);
		springLayout.putConstraint(springLayout.WEST, welcomeRegisterLabel, 60, springLayout.WEST, c);
		
		c.add(userLabel);//用户名设置
		springLayout.putConstraint(springLayout.NORTH, userLabel, 30, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, userLabel, 60, springLayout.WEST, c);
		c.add(userjt);
		springLayout.putConstraint(springLayout.NORTH, userjt, 30, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, userjt, 10, springLayout.EAST, userLabel);
		
		c.add(tipUserAlreadyRegistered);//提示该账号已经注册
		springLayout.putConstraint(springLayout.NORTH, tipUserAlreadyRegistered, 34, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipUserAlreadyRegistered, 5, springLayout.EAST, userjt);
		c.add(tipUserNameEmpty);//提示用户名不能为空
		springLayout.putConstraint(springLayout.NORTH, tipUserNameEmpty, 34, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipUserNameEmpty, 5, springLayout.EAST, userjt);
		c.add(tipUserNameLessThan5Char);//提示用户名少于五个字符
		springLayout.putConstraint(springLayout.NORTH, tipUserNameLessThan5Char, 34, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipUserNameLessThan5Char, 5, springLayout.EAST, userjt);
		
		c.add(passwordLabel);//密码设置
		springLayout.putConstraint(springLayout.NORTH, passwordLabel, 23, springLayout.SOUTH, userLabel);
		springLayout.putConstraint(springLayout.WEST, passwordLabel, 77, springLayout.WEST, c);
		c.add(passwordjp);
		springLayout.putConstraint(springLayout.NORTH, passwordjp, 20, springLayout.SOUTH, userjt);
		springLayout.putConstraint(springLayout.WEST, passwordjp, 10, springLayout.EAST, passwordLabel);
		
		c.add(tipPasswordEmpty);//提示密码不能为空
		springLayout.putConstraint(springLayout.NORTH, tipPasswordEmpty, 82, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipPasswordEmpty, 5, springLayout.EAST, passwordjp);
		c.add(tipPasswordLessThan6Char);//提示密码少于五个字符
		springLayout.putConstraint(springLayout.NORTH, tipPasswordLessThan6Char, 82, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipPasswordLessThan6Char, 5, springLayout.EAST, passwordjp);
	
		c.add(confirmPasswordLabel);//确认密码标签
		springLayout.putConstraint(springLayout.NORTH, confirmPasswordLabel, 23, springLayout.SOUTH, passwordLabel);
		springLayout.putConstraint(springLayout.WEST, confirmPasswordLabel, 41, springLayout.WEST, c);
		c.add(confirmPasswordjp);
		springLayout.putConstraint(springLayout.NORTH, confirmPasswordjp, 20, springLayout.SOUTH, passwordjp);
		springLayout.putConstraint(springLayout.WEST, confirmPasswordjp, 10, springLayout.EAST, confirmPasswordLabel);
		
		c.add(tipPasswordInconfirmity);//提示两次输入密码不一致
		springLayout.putConstraint(springLayout.NORTH, tipPasswordInconfirmity, 128, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipPasswordInconfirmity, 5, springLayout.EAST, confirmPasswordjp);
		c.add(tipConfirmPasswordqualified);//提示两次输入密码一致
		springLayout.putConstraint(springLayout.NORTH, tipConfirmPasswordqualified, 128, springLayout.SOUTH, welcomeRegisterLabel);
		springLayout.putConstraint(springLayout.WEST, tipConfirmPasswordqualified, 5, springLayout.EAST, confirmPasswordjp);
		
		c.add(yanzhengmajl);//验证码设置
		springLayout.putConstraint(springLayout.NORTH, yanzhengmajl, 39, springLayout.SOUTH, confirmPasswordLabel);
		springLayout.putConstraint(springLayout.WEST, yanzhengmajl, 59, springLayout.WEST, c);
		c.add(yanzhengmajt);
		springLayout.putConstraint(springLayout.NORTH, yanzhengmajt, 36, springLayout.SOUTH, confirmPasswordjp);
		springLayout.putConstraint(springLayout.WEST, yanzhengmajt, 10, springLayout.EAST, yanzhengmajl);
		
		c.add(yanzhengmaUpdate);
		springLayout.putConstraint(springLayout.NORTH, yanzhengmaUpdate, 40, springLayout.SOUTH, confirmPasswordjp);
		springLayout.putConstraint(springLayout.WEST, yanzhengmaUpdate, 115, springLayout.EAST, yanzhengmajt);
		
		c.add(tipyanzhengmaerror);//提示验证码错误
		springLayout.putConstraint(springLayout.NORTH, tipyanzhengmaerror, 5, springLayout.SOUTH, yanzhengmajt);
		springLayout.putConstraint(springLayout.WEST, tipyanzhengmaerror, 145, springLayout.WEST, c);
		
		c.add(register);//注册按钮
		springLayout.putConstraint(springLayout.NORTH, register, 35, springLayout.SOUTH, yanzhengmajt);
		springLayout.putConstraint(springLayout.WEST, register, 140, springLayout.WEST, c);
		
		c.add(back);////返回标签
		springLayout.putConstraint(springLayout.NORTH, back, 10, springLayout.SOUTH, register);
		springLayout.putConstraint(springLayout.WEST, back, 340, springLayout.WEST, c);
		
		//添加鼠标事件监听器
		yanzhengmaUpdate.addMouseListener(new MouseListener() {//验证码刷新按钮
			public void mouseClicked( MouseEvent e) {
				repaint();
			}
			public void mouseEntered(MouseEvent e) {
				yanzhengmaUpdate.setForeground(Color.red);
			}
			public void mouseExited(MouseEvent e) {
				yanzhengmaUpdate.setForeground(Color.black);
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
		userjt.addMouseListener(new MouseAdapter() {//用户单击文本框
			public void mouseClicked(MouseEvent e) {
				userjt.setText("");
			}
		});
		passwordjp.addMouseListener(new MouseAdapter() {//用户单击密码框
			public void mouseClicked(MouseEvent e) {
				passwordjp.setText("");
			}
		});
		confirmPasswordjp.addMouseListener(new MouseAdapter() {//点击重复密码框
			public void mouseClicked(MouseEvent e) {
				confirmPasswordjp.setText("");
			}
		});
		yanzhengmajt.addMouseListener(new MouseAdapter() {//用户单击验证码输入框
			public void mouseClicked(MouseEvent e) {
				yanzhengmajt.setText("");
			}
		});
		register.addActionListener(new ActionListener() {//为注册按钮设置监听器
			public void actionPerformed(ActionEvent e) {
				userName = userjt.getText().trim();//验证用户名
				if(new FileOperation().readData("user.xls", userName)) {//用户名已经存在
					tipUserAlreadyRegistered.setVisible(true);//提示账号已经被注册提示
					tipUserNameEmpty.setVisible(false);//隐藏账号为空提示
					tipUserNameLessThan5Char.setVisible(false);//隐藏账号长度小于五个字符
					flagUserName = 0;
				}
				else if(userName.length() < 5 && userName.length() > 0){
					tipUserNameLessThan5Char.setVisible(true);//提示账号长度小于五个字符
					tipUserAlreadyRegistered.setVisible(false);//隐藏账号已经被注册提示
					tipUserNameEmpty.setVisible(false);//隐藏账号为空提示
					flagUserName = 0;
				}
				else if(userName.length() == 0) {
					tipUserNameEmpty.setVisible(true);//提示账号为空提示
					tipUserNameLessThan5Char.setVisible(false);//隐藏账号长度小于五个字符
					tipUserAlreadyRegistered.setVisible(false);//隐藏账号已经被注册提示
					flagUserName = 0;
				}
				else {
					tipUserNameLessThan5Char.setVisible(false);//隐藏账号长度小于五个字符
					tipUserAlreadyRegistered.setVisible(false);//隐藏账号已经被注册提示
					tipUserNameEmpty.setVisible(false);//隐藏账号为空提示
					flagUserName = 1;
				}
				
				password = new String(passwordjp.getPassword()).trim();//验证密码
				if(password.length() < 6 && password.length() > 0) {
					tipPasswordLessThan6Char.setVisible(true);//提示密码小于五个字符
					tipPasswordEmpty.setVisible(false);//隐藏密码为空提示
					flagPassword = 0;
				}
				else if(password.length() == 0) {
					tipPasswordEmpty.setVisible(true);//提示密码为空提示
					tipPasswordLessThan6Char.setVisible(false);//隐藏密码小于五个字符
					flagPassword = 0;
				}
				else {
					tipPasswordLessThan6Char.setVisible(false);//隐藏密码小于五个字符
					tipPasswordEmpty.setVisible(false);//隐藏密码为空提示
					flagPassword = 1;
				}
				
				repeatPassword = new String(confirmPasswordjp.getPassword()).trim();//验证重复密码
				if(repeatPassword.length() >= 6 && repeatPassword.equals(password)) {
					tipConfirmPasswordqualified.setVisible(false);//提示重复密码正确
					tipPasswordInconfirmity.setVisible(false);//隐藏从夫密码错误提示
					flagConfirmedPassword = 1;
				}
				else if(! repeatPassword.equals(password)){
					tipPasswordInconfirmity.setVisible(true);//显示重复密码错误提示
					tipConfirmPasswordqualified.setVisible(false);//隐藏重复密码正确	
					flagConfirmedPassword = 0;
				}
				else {
					tipPasswordInconfirmity.setVisible(false);//隐藏重复密码错误提示
					tipConfirmPasswordqualified.setVisible(false);//隐藏重复密码正确	
					flagConfirmedPassword = 0;
				}
				
				yanzhengma = yanzhengmajt.getText().trim();//检查验证码是否正确
				if(yanzhengma.equalsIgnoreCase(yzm)) {
					tipyanzhengmaerror.setVisible(false);//隐藏验证码错误提示
					flagyanzhengma = 1;
				}
				else {
					tipyanzhengmaerror.setVisible(true);//提示验证码错误提示
					flagyanzhengma = 0;
				}
				
				if(flagUserName == 1 && flagPassword == 1 && 
						flagConfirmedPassword == 1 && flagyanzhengma == 1) {//表示上面填写的内容符合要求
					//将用户信息写入文件中
					new FileOperation().writeData("user.xls", userName, "userName", userName);
					new FileOperation().writeData("user.xls", userName, "password", password);
					new FileOperation().writeData("user.xls", userName, "points", "0");
					new FileOperation().writeData("user.xls", userName, "class", "0");
					new FileOperation().writeData("user.xls", userName, "winNum", "0");
					new FileOperation().writeData("user.xls", userName, "totalNum", "0");
					new FileOperation().writeData("user.xls", userName, "RememberPassword", "0");
					new FileOperation().writeData("user.xls", userName, "AutoLogin", "0");
					//将注册时间写入文件中
					Date date = new Date();
					String form = String.format("%tF", date);
					new FileOperation().writeData("user.xls", userName, "date", form);
					dispose();//销毁当前窗口
					new Main();
				}
				else {
					;
				}
			}
		});
		back.addMouseListener(new MouseListener() {//返回按钮
			public void mouseClicked(MouseEvent e) {
				dispose();
				new Main();
			}
			public void mouseEntered(MouseEvent e) {
				back.setForeground(Color.red);
			}
			public void mouseExited(MouseEvent e) {
				back.setForeground(Color.black);
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
	}
	
	/**********************************************验证码*****************************************/
	class DrawYZM extends JPanel{
		/*
		 *验证码类
		 */
		public void paint(Graphics g) {
			setBounds(269, 269, 100, 60);
			int R = r.nextInt(255);
			int G = r.nextInt(255);
			int B = r.nextInt(255);
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D)g;
		    int n = 0;
		    yzm = "";
			for(int i = 0; i < 4; i++) {
				n = r.nextInt(62);
				yzm += YZM[n];
				int flag = r.nextInt(2);
				Color color = new Color(r.nextInt(200) + 20, r.nextInt(200) + 20, r.nextInt(200) + 20);
				g2.setColor(color);
				Graphics2D g2d = (Graphics2D)g;
				AffineTransform trans = new AffineTransform();//将文字旋转指定角度
				if(flag == 0) {
					trans.rotate(- r.nextInt(45) * 3.14 / 180, 275 + i * 25, 307);
				}else {
					trans.rotate(r.nextInt(45) * 3.14 / 180, 275 + i * 25, 307);
				}
				g2d.setTransform(trans);
				g2.setFont(new Font("微软雅黑", 1, 24));
				g2.drawString(YZM[n] + "", 277 + i * 22, 307);
			}
			
		}
	}

}
